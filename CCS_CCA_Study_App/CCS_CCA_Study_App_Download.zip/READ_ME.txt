Extract this ZIP first. Open CCS_CCA_1300_AO_Applied_Edition.html in your browser for the interactive study app. Open CCS_CCA_150_AO_Scenarios_Printable.html for the printable scenarios.
